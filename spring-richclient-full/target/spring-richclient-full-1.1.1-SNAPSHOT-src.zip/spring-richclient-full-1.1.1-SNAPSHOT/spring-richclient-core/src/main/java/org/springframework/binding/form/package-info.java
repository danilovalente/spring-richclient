/**
 * FormModel related interfaces.
 */
package org.springframework.binding.form;