/**
 * Closure and constraint function object core support implementations.
 */
package org.springframework.rules.closure.support;