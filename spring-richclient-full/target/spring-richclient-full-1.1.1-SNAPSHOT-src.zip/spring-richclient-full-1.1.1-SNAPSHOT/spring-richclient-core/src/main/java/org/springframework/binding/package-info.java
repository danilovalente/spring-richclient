/**
 * Base interfaces for property read/write access.
 */
package org.springframework.binding;