/**
 * Validation interfaces.
 */
package org.springframework.binding.validation;