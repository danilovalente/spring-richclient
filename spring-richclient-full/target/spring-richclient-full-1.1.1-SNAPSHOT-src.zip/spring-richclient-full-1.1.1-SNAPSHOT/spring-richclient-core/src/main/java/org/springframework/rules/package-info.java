/**
 * Core interfaces for the expression and function object/rules library.
 * Adapted from commons-functor.
 */
package org.springframework.rules;