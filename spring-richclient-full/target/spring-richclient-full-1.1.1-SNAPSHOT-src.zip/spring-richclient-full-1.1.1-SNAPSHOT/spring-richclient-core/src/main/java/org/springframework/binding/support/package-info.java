/**
 * Implementations of the property access interfaces providing basic bean/class access.
 */
package org.springframework.binding.support;