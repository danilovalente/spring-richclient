/**
 * Basic interfaces/classes used throughout the richclient.
 */
package org.springframework.richclient.core;