/**
 * Out of the box functions that address common needs.
 */
package org.springframework.rules.closure;