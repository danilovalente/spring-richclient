/**
 * Some helper classes.
 */
package org.springframework.richclient.util;