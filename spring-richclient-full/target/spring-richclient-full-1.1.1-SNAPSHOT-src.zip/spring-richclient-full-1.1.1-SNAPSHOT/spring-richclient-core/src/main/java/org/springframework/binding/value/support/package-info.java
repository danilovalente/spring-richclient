/**
 * Supporting value model and value holder implementations.
 */
package org.springframework.binding.value.support;