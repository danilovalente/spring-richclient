/*
 * Copyright 2002-2008 the original author or authors.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package org.springframework.richclient.selection.binding.support;

import java.awt.Component;

import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;

/**
 * <code>ListCellRenderer</code> implementation that uses a <code>LabelProvider</code> to render the text.
 * 
 * @author Peter De Bruycker
 */
public class LabelProviderListCellRenderer extends DefaultListCellRenderer {
    private static final long serialVersionUID = 1L;

    private LabelProvider labelProvider;

    public LabelProviderListCellRenderer(LabelProvider labelProvider) {
        this.labelProvider = labelProvider;
    }

    public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
            boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

        setText(labelProvider.getLabel(value));

        return this;
    }
}
