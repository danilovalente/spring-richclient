/**
 * Core value model interfaces, for accessing values from abritrary sources.
 */
package org.springframework.binding.value;