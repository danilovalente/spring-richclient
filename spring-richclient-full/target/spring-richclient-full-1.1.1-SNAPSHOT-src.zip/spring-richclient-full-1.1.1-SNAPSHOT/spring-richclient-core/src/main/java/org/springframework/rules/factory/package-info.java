/**
 * Factories for creating rules.
 */
package org.springframework.rules.factory;