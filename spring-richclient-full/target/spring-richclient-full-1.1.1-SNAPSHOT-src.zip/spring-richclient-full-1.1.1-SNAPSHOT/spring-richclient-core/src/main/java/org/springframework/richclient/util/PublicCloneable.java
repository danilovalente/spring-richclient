package org.springframework.richclient.util;

public interface PublicCloneable
{
    public Object clone() throws CloneNotSupportedException;
}
