/**
 * Rules result reporting interfaces and classes.
 */
package org.springframework.rules.reporting;