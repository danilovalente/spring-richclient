/**
 * Out of the box predicates and constraint building blocks involving bean properties.
 */
package org.springframework.rules.constraint.property;