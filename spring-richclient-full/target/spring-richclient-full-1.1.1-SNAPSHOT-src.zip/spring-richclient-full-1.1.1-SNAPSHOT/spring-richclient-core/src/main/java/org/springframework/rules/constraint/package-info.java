/**
 * Out of the box predicates that address common needs such as comparison and composition.
 */
package org.springframework.rules.constraint;